import { Component, OnInit } from '@angular/core';
import { NewserviceService } from '../services/newservice.service';
import { FormGroup, FormControl } from '@angular/forms';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit{
images:any=[];
  constructor(private employeeservice:NewserviceService) {
    
   }
  ngOnInit(){  
    this.employeeservice.getEmpolyees().subscribe((data:any)=>{
      this.images=data.message
    });
  } 
  
  mainForm =new FormGroup({
    firstname: new FormControl(),
    lastname:new FormControl(),
   })
   onSubmit(){
     console.log(this.mainForm.value);
   }
  }

